/* ******************************
 *  Name:       Peter Tran Huynh
 *  Title:      HW1 - NDC to RGB Shader
 *  Course:     CSCI 4239
 *  Semester:   Spring 2017
 *  File Notes: 
 *    GUI Viewer Header
 ***************************** */

#ifndef HW1V_H
#define HW1V_H

#include <QWidget>

class Hw1viewer : public QWidget
{
Q_OBJECT
public:
    Hw1viewer();
};

#endif
