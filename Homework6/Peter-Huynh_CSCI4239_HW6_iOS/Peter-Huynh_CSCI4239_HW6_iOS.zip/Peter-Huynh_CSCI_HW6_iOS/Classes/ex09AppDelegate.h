#import "GLView.h"

@interface ex09AppDelegate : NSObject <UIApplicationDelegate>
{
@private
   UIWindow* window;  //  Pointer to UI window
   GLView*   glview;  //  Pointer to GL view
}

@end

