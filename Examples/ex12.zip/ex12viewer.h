#ifndef EX12V_H
#define EX12V_H

#include <QWidget>
#include <QSlider>
#include <QDoubleSpinBox>
#include "ex12opengl.h"

class Ex12viewer : public QWidget
{
Q_OBJECT
public:
    Ex12viewer();
};

#endif
