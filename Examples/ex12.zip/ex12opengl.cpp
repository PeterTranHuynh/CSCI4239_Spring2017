//
//  OpenGL widget
//
#include "ex12opengl.h"

//
//  Constructor
//
Ex12opengl::Ex12opengl(QWidget* parent)
    : CUgl(parent)
{
   N = 1;
   x0 = y0 = 0;
   zoom = 1;
   Cw = Ch = 0;
   frame = 0;
   framebuf[0] = 0;
   framebuf[1] = 0;
}

//
//  Reset view
//
void Ex12opengl::reset()
{
   x0 = y0 = 0;
   zoom = 1;
   //  Request redisplay
   update();
}

//
//  Set passes
//
void Ex12opengl::setPasses(int n)
{
   N = n;
   //  Request redisplay
   update();
}

//
//  Set image
//
void Ex12opengl::setImage(QImage img)
{
   //  Copy image to texture
   glBindTexture(GL_TEXTURE_2D,frame);
   QImage rgba = QGLWidget::convertToGLFormat(img);
   Cw = rgba.width();
   Ch = rgba.height();
   glTexImage2D(GL_TEXTURE_2D,0,4,Cw,Ch,0,GL_RGBA,GL_UNSIGNED_BYTE,rgba.bits());
   //  Allocate frame buffer objects to native camera resolution
   if (!framebuf[0] || framebuf[0]->width() != Cw|| framebuf[0]->height() != Ch)
   {
      for (int k=0;k<2;k++)
      {
         //  Allocate frame buffer objects
         if (framebuf[k]) delete framebuf[k];
         framebuf[k] = new QGLFramebufferObject(Cw,Ch);
      }
   }
   //  Request redisplay
   update();
}

//
//  Initialize
//
void Ex12opengl::initializeGL()
{
   //  Load shaders
   addShader("",":/ex12a.frag");
   addShader("",":/ex12b.frag");
   addShader("",":/ex12c.frag");
   addShader("",":/ex12d.frag");
   addShader("",":/ex12e.frag");
   addShader("",":/ex12f.frag");
   addShader("",":/ex12g.frag");
   addShader("",":/ex12h.frag");

   //  Initialize image capture texture
   glGenTextures(1,&frame);
   glBindTexture(GL_TEXTURE_2D,frame);
}

//
//  Draw the window
//
void Ex12opengl::paintGL()
{
   //  Starting texture
   glBindTexture(GL_TEXTURE_2D,frame);
   glEnable(GL_TEXTURE_2D);
   //  Camera aspect ratio
   float Casp = Cw / (float)Ch;

   //  Process
   if (mode)
   {
      //  Viewport is entire image
      glViewport(0,0,Cw,Ch);
      //  Set Projection
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      glOrtho(-Casp, +Casp, -1, +1, -1, +1);
      //  Set ModelView
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      //  Enable shader
      shader[mode]->bind();

      //  Set shader increments
      shader[mode]->setUniformValue("dX",(float)1.0/Cw);
      shader[mode]->setUniformValue("dY",(float)1.0/Ch);

      //  Ping-Pong at camera resolution
      for (int k=0;k<N;k++)
      {
         //  Pick nearest pixel
         glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
         glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
         //  Set output buffer
         framebuf[k%2]->bind();
         //  Draw image
         glClear(GL_COLOR_BUFFER_BIT);
         glBegin(GL_QUADS);
         glTexCoord2f(0,0); glVertex2f(-Casp,-1);
         glTexCoord2f(1,0); glVertex2f(+Casp,-1);
         glTexCoord2f(1,1); glVertex2f(+Casp,+1);
         glTexCoord2f(0,1); glVertex2f(-Casp,+1);
         glEnd();
         //  Release output buffer
         framebuf[k%2]->release();
         //  Bind texture to result
         glBindTexture(GL_TEXTURE_2D,framebuf[k%2]->texture());
      }

      //  Release shader
      shader[mode]->release();
   }

   //  Set pixel interpolation
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
   //  Window aspect ratio
   float Wasp = width() / (float)height();
   //  Viewport is entire window
   glViewport(0,0,width(),height());
   //  Set Projection
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-Wasp, +Wasp, -1, +1, -1, +1);
   //  Set ModelView
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glScaled(zoom,zoom,1);
   glTranslated(x0,y0,0);
   //  Draw to screen
   glClear(GL_COLOR_BUFFER_BIT);
   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex2f(-Casp,-1);
   glTexCoord2f(1,0); glVertex2f(+Casp,-1);
   glTexCoord2f(1,1); glVertex2f(+Casp,+1);
   glTexCoord2f(0,1); glVertex2f(-Casp,+1);
   glEnd();
   //  Done with textures
   glDisable(GL_TEXTURE_2D);
}

/******************************************************************/
/*************************  Mouse Events  *************************/
/******************************************************************/
//
//  Mouse moved
//
void Ex12opengl::mouseMoveEvent(QMouseEvent* e)
{
   if (mouse)
   {
      QPoint d = e->pos()-pos;      //  Change in mouse location
      x0 += d.x()/(zoom*width());   //  Translate x movement to azimuth
      y0 -= d.y()/(zoom*height());  //  Translate y movement to elevation
      pos = e->pos();               //  Remember new location
      update();                   //  Request redisplay
   }
}

//
//  Mouse wheel
//
void Ex12opengl::wheelEvent(QWheelEvent* e)
{
   //  Zoom out
   if (e->delta()<0)
      zoom *= 1.05;
   //  Zoom in
   else if (zoom>1)
      zoom /= 1.05;
   //  Request redisplay
   update();
}
