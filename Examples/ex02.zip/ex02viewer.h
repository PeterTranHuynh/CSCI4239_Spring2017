#ifndef EX02V_H
#define EX02V_H

#include <QWidget>

class Ex02viewer : public QWidget
{
Q_OBJECT
public:
    Ex02viewer();
};

#endif
