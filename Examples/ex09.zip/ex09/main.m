//  Example 09:  iPhone OpenGL ES
//  This program borrow heavily from the HellowArrow example in
//  iPhone 3D Programming by Philip Rideout


int main(int argc, char *argv[])
{
   NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
   int retVal = UIApplicationMain(argc, argv, nil, @"ex09AppDelegate");
   [pool release];
   return retVal;
}
