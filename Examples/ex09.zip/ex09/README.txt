Example 09:  iPhone OpenGL ES

This program borrows heavily from the HellowArrow example in iPhone 3D
Programming by Philip Rideout.  The basic framework is the same, but
the program has ben modified to draw a 3D cube instead of a 2D arrow.

BUILDING

This program will only run on a Mac.  To build it do

open ex09.xcodeproj

This will start up Xcode.  To run click on "Build and Run".
The project was developed usng Xcode 4.5.2 and iOS Simulator 6.0
You may need to get a similar version for the Xcode to run this project.

RUNNING:

Press APPLE -> and APPLE <- to tilt the screen.  The cube will
right itself in about a second or so.
